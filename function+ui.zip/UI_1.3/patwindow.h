#ifndef PATWINDOW_H
#define PATWINDOW_H

#include <QWidget>
#include <QTreeWidgetItem>
#include <QString>
#include <QDebug>
#include <QUdpSocket>
#include <QHostAddress>
#include <QMessageBox>

namespace Ui {
class patWindow;
}

#define MALE 0
#define FEMALE 1

#define ORD_SERVER_IP "192.168.3.10"
#define ORD_SERVER_PORT 1234

#define DISORD_SERVER_IP "192.168.3.10"
#define DISORD_SERVER_PORT 1234

#define GETMES_SERVER_IP "192.168.3.10"
#define GETMES_SERVER_PORT 1234

//#define GETMES_CLIENT_IP "192.168.1.1"
//#define GETMES_CLIENT_PORT 1233
struct getdocmes_struct
{
    int num_ver = 0x04;//版本号0x04
    int type = 7;//类型07表示是请求医生信息
    int check_crc = 0;//不进行校验
};

struct doc_info
{
    QString doc_name;
    int  doc_sex;
    int  doc_age;
};

struct order_struct
{
    int num_ver = 0x04;//版本号0x04
    int type = 3;//类型03表示是预约信息
    char order_name_pat[20];
    char order_name_doc[20];
    int check_crc = 0;//不进行校验
};

struct disord_struct
{
    int num_ver = 0x04;//版本号0x04
    int type = 4;//类型04表示是取消预约信息
    char disord_name_pat[20];
    char disord_name_doc[20];
    int check_crc = 0;//不进行校验
};

class patWindow : public QWidget
{
    Q_OBJECT

public:
    explicit patWindow(QString name_pat, QWidget *parent = 0);
    ~patWindow();

    QString name_patient;// 患者姓名
    struct doc_info docInfo[100];
    int count_doc=1;
    int item_check=-1; // 选中医生序号，-1表示没有选中

private slots:
    void on_patwindow_btn_quit_clicked();

    void on_patwindow_tree_doc_itemDoubleClicked(QTreeWidgetItem *item, int column);

    void on_patwindow_btn_order_clicked();

    void on_patwindow_btn_disorder_clicked();

    void slot_readyread_doc();

private:
    Ui::patWindow *ui;
    QUdpSocket *order_udpsock;//声明udp对象
    QUdpSocket *getmes_udpsock;
    //QUdpSocket *getmes_udpsock_rcv;
    QString name_doctor;
};

#endif // PATWINDOW_H
