#include "regwindow.h"
#include "ui_regwindow.h"

regWindow::regWindow(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::regWindow)
{
    ui->setupUi(this);

    //显示提示
    ui->regwindow_ledit_usr->setPlaceholderText("请输入用户名");
    ui->regwindow_ledit_passwd->setPlaceholderText("请输入密码");
    ui->regwindow_ledit_passwd_cfm->setPlaceholderText("请再次确认密码");
    ui->regwindow_ledit_age->setPlaceholderText("请输入年龄");
    ui->regwindow_ledit_passwd->setEchoMode(QLineEdit::Password);//设置密码为暗文显示
    ui->regwindow_ledit_passwd_cfm->setEchoMode(QLineEdit::Password);
    ui->regwindow_btn_reg->setCursor(QCursor(Qt::PointingHandCursor));//设置鼠标放在按钮上时为手型
    ui->regwindow_btn_quit->setCursor(QCursor(Qt::PointingHandCursor));
    ui->regwindow_rbtn_prof_doc->setCursor(QCursor(Qt::PointingHandCursor));
    ui->regwindow_rbtn_prof_pat->setCursor(QCursor(Qt::PointingHandCursor));
    ui->regwindow_rbtn_sex_man->setCursor(QCursor(Qt::PointingHandCursor));
    ui->regwindow_rbtn_sex_wom->setCursor(QCursor(Qt::PointingHandCursor));
    this->setWindowTitle("欢迎注册");

    rbtnGroup_pro = new QButtonGroup(this);//按钮分组
    rbtnGroup_sex = new QButtonGroup(this);
    rbtnGroup_pro->addButton(ui->regwindow_rbtn_prof_doc, 0);
    rbtnGroup_pro->addButton(ui->regwindow_rbtn_prof_pat, 1);
    rbtnGroup_sex->addButton(ui->regwindow_rbtn_sex_man, 0);
    rbtnGroup_sex->addButton(ui->regwindow_rbtn_sex_wom, 1);

    ui->regwindow_rbtn_prof_pat->setChecked(true);//默认是男患者
    ui->regwindow_rbtn_prof_doc->setChecked(false);
    ui->regwindow_rbtn_sex_man->setChecked(true);
    ui->regwindow_rbtn_sex_wom->setChecked(false);

    //定义udp对象
    reg_udpsock = new QUdpSocket();
}

regWindow::~regWindow()
{
    delete ui->regwindow_ledit_usr;
    delete ui->regwindow_ledit_passwd;
    delete ui->regwindow_ledit_passwd_cfm;
    delete ui->regwindow_ledit_age;
    delete ui->regwindow_btn_reg;
    delete ui->regwindow_btn_quit;
    delete ui->regwindow_rbtn_prof_doc;
    delete ui->regwindow_rbtn_prof_pat;
    delete ui->regwindow_rbtn_sex_man;
    delete ui->regwindow_rbtn_sex_wom;
    delete rbtnGroup_pro;
    delete rbtnGroup_sex;
    delete ui;
}

void regWindow::on_regwindow_btn_quit_clicked()
{
    this->close();
}

void regWindow::on_regwindow_btn_reg_clicked()
{
    //发送的数据：用户名，密码，年龄，性别，职业
    //1 将发送的数据打包
    QString usr = ui->regwindow_ledit_usr->text();
    QString passwd = ui->regwindow_ledit_passwd->text();
    QString passwd_cfm = ui->regwindow_ledit_passwd_cfm->text();
    int prof=1;
    int sex=1;
    if(passwd != passwd_cfm)
    {
        QMessageBox::information(this, "注册信息", "两次输入密码不一致，请重新输入");
        return;
    }
    else
    {
        QString age_str = ui->regwindow_ledit_age->text();
        if(usr.isEmpty() || passwd.isEmpty() || age_str.isEmpty())
        {
            QMessageBox::information(this, "注册信息", "请输入完整注册信息！");
            return;
        }
        switch(rbtnGroup_pro->checkedId())
        {
            case 0:
                prof = DOCTOR;
                break;
            case 1:
                prof = PATIENT;
                break;
        }
        switch(rbtnGroup_sex->checkedId())
        {
            case 0:
                sex = MALE;
                break;
            case 1:
                sex = FEMALE;
                break;
        }
        //封装数据：结构体
        struct reg_struct reg;
        //usr.toStdString().c_str()将QString转换为C语言字符串，然后放到reg.reg_usr里去
        qsnprintf(reg.reg_usr, 20, usr.toStdString().c_str());
        qsnprintf(reg.reg_passwd, 20, passwd.toStdString().c_str());
        reg.reg_age = age_str.toInt();
        reg.reg_sex = sex;
        reg.reg_prof = prof;
        qDebug()<<usr<<":"<<passwd<<":"<<reg.reg_age<<":"<<prof<<":"<<sex;//打印信息
//        //2 将注册信息发送给服务器端（云端）
        QHostAddress *addr = new QHostAddress(REG_SERVER_IP);
        qint64 ret = reg_udpsock->writeDatagram((char *)&reg, sizeof(reg), *addr, REG_SERVER_PORT);
        if(ret < 0)
        {
            QMessageBox::information(this, "注册信息", "注册窗口发送数据失败！");
            this->close();
            return;
        }
        else
        {
            QMessageBox::information(this, "注册信息", "注册成功！");
            this->close();
        }
    }
}
