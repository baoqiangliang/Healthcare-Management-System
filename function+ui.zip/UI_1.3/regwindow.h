#ifndef REGWINDOW_H
#define REGWINDOW_H

#include <QWidget>
#include <QButtonGroup>
#include <QMessageBox>
#include <QString>
#include <QUdpSocket>
#include <QHostAddress>

namespace Ui {
class regWindow;
}

#define MALE 0
#define FEMALE 1

#define DOCTOR 0
#define PATIENT 1

#define REG_SERVER_IP "192.168.3.10"
#define REG_SERVER_PORT 1234

struct reg_struct
{
    int num_ver = 0x04;//版本号0x04
    int type = 1;//类型01表示是注册信息
    char reg_usr[20];
    char reg_passwd[20];
    int reg_age;
    int reg_sex;
    int reg_prof;
    int check_crc = 0;//不进行校验
};

class regWindow : public QWidget
{
    Q_OBJECT

public:
    explicit regWindow(QWidget *parent = 0);
    ~regWindow();

private slots:
    void on_regwindow_btn_quit_clicked();

    void on_regwindow_btn_reg_clicked();

private:
    Ui::regWindow *ui;

    QButtonGroup *rbtnGroup_pro;
    QButtonGroup *rbtnGroup_sex;

    QUdpSocket *reg_udpsock;//声明udp对象
};

#endif // REGWINDOW_H
