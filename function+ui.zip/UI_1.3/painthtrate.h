#ifndef PAINTHTRATE_H
#define PAINTHTRATE_H

#include <QWidget>
#include <QPainter>
#include <QList>
#include <QTimer>
#include <QtCore/qmath.h>
#include <QPointF>
#include <QDebug>

namespace Ui {
class paintHtrate;
}

class paintHtrate : public QWidget
{
    Q_OBJECT

public:
    explicit paintHtrate(float* htrate, QWidget *parent = 0);
    ~paintHtrate();
    void paintEvent(QPaintEvent*);
    float* htRate;

public slots:
    void slot_update_data(void);

private:
    Ui::paintHtrate *ui;
    //QList<float>表示列表QList中存放的数据的类型是float
    QList<int> xList;   //横坐标为时间
    QList<float> yList; //纵坐标为心率
    QTimer *m_timer;
    int x;
    int draw_count;
};

#endif // PAINTHTRATE_H
