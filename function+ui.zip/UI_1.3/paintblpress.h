#ifndef PAINTBLPRESS_H
#define PAINTBLPRESS_H

#include <QWidget>
#include <QPainter>
#include <QList>
#include <QTimer>
#include <QtCore/qmath.h>
#include <QPointF>
#include <QDebug>

namespace Ui {
class paintBlpress;
}

class paintBlpress : public QWidget
{
    Q_OBJECT

public:
    explicit paintBlpress(float* blpress, QWidget *parent = 0);
    ~paintBlpress();
    void paintEvent(QPaintEvent*);
    float* blPress;

public slots:
    void slot_update_data(void);

private:
    Ui::paintBlpress *ui;
    //QList<float>表示列表QList中存放的数据的类型是float
    QList<int> xList;   //横坐标为时间
    QList<float> yList; //纵坐标为血压
    QTimer *m_timer;
    int x;
    int draw_count;
};

#endif // PAINTBLPRESS_H
