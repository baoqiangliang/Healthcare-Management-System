#include "docwindow.h"
#include "ui_docwindow.h"

docWindow::docWindow(QString name_doc, QWidget *parent) :
    QWidget(parent),
    ui(new Ui::docWindow)
{
    ui->setupUi(this);

    this->setWindowTitle("欢迎使用医疗管理系统");
    //定义定时器
    timer = new QTimer(this);
    //设置定时器超时时执行的槽函数
    connect(timer,SIGNAL(timeout()),this,SLOT(slot_timeout()));
    ui->docwindow_btn_bodytmp_pat->setCursor(QCursor(Qt::PointingHandCursor));//设置鼠标放在按钮上时为手型
    ui->docwindow_btn_htrate_pat->setCursor(QCursor(Qt::PointingHandCursor));
    ui->docwindow_btn_blpress_pat->setCursor(QCursor(Qt::PointingHandCursor));
    ui->docwindow_btn_quit->setCursor(QCursor(Qt::PointingHandCursor));
    ui->docwindow_btn_discharge->setCursor(QCursor(Qt::PointingHandCursor));

    //定义udp对象
    doc_udpsock = new QUdpSocket();
    //doc_udpsock_rcv = new QUdpSocket();
    //将接受数据的进程与ip和端口号绑定
    //doc_udpsock_rcv->bind(QHostAddress(DOC_CLIENT_IP), DOC_CLIENT_PORT);
    //udp接收数据：当udp接收到数据后，会产生一个readyRead()信号，将该信号与一个接收槽函数关联
    //connect(doc_udpsock_rcv, SIGNAL(readyRead()), this, SLOT(slot_readyread()));
    connect(doc_udpsock, SIGNAL(readyRead()), this, SLOT(slot_readyread()));

    name_doctor = name_doc;

            //测试用，从云端获取患者信息后注释
//            float temp_arr[30]={36.4,36.5,36.3,36.8,36.2,36.7,37.1,37.2,37.5,36.4,36.5,36.8,37.4,37.8,37.9,38.0,38.2,38.3,38.2,38.1,38.0,38.0,38.0,37.5,37.4,37.1,37.0,36.9,36.8,36.6};
//            count_pat=3;
//            patInfo[0].pat_name="方时";
//            patInfo[0].pat_sex=MALE;
//            patInfo[0].pat_age=30;
//            memcpy(patInfo[0].body_tmp, temp_arr, sizeof(temp_arr));
//            qDebug() << patInfo[0].body_tmp[29];
//            memcpy(patInfo[0].hrt_rate, temp_arr, sizeof(temp_arr));
//            memcpy(patInfo[0].bld_press, temp_arr, sizeof(temp_arr));
//            patInfo[0].pat_cond="感冒";
//            patInfo[1].pat_name="佟梦";
//            patInfo[1].pat_sex=FEMALE;
//            patInfo[1].pat_age=25;
//            memcpy(patInfo[1].body_tmp, temp_arr, sizeof(temp_arr));
//            memcpy(patInfo[1].hrt_rate, temp_arr, sizeof(temp_arr));
//            memcpy(patInfo[1].bld_press, temp_arr, sizeof(temp_arr));
//            patInfo[1].pat_cond="头晕";
//            patInfo[2].pat_name="莫朵";
//            patInfo[2].pat_sex=FEMALE;
//            patInfo[2].pat_age=24;
//            memcpy(patInfo[2].body_tmp, temp_arr, sizeof(temp_arr));
//            memcpy(patInfo[2].hrt_rate, temp_arr, sizeof(temp_arr));
//            memcpy(patInfo[2].bld_press, temp_arr, sizeof(temp_arr));
//            patInfo[2].pat_cond="发烧";

    ui->docwindow_tree_pat->setHeaderLabel(name_doc+"医生，您好");

    //向云端请求患者信息
    //发送的数据：医生姓名
    //1 将发送的数据打包
    //封装数据：结构体
    struct reqInfo_struct req;
    qsnprintf(req.docName, 20, name_doctor.toStdString().c_str());
    qDebug()<<req.docName;//打印信息
    //2 将请求患者信息发送给服务器端（云端）
        QHostAddress *addr = new QHostAddress(REQINFO_SERVER_IP);
        qint64 ret = doc_udpsock->writeDatagram((char *)&req, sizeof(req), *addr, REQINFO_SERVER_PORT);
        if(ret < 0)
        {
            QMessageBox::information(this, "获取患者信息", "获取患者信息失败！");
            return;
        }



    //int column_pat=count_pat-1;

    ui->docwindow_tbrow_name_pat->setText("姓名：");
    ui->docwindow_tbrow_sex_pat->setText("性别：");
    ui->docwindow_tbrow_age_pat->setText("年龄：");
    ui->docwindow_tedit_cond_pat->setText("病情：");
    ui->docwindow_tbrow_bodytmp_pat->setText("体温：");
    ui->docwindow_tbrow_htrate_pat->setText("心率：");
    ui->docwindow_tbrow_blpress_pat->setText("血压：");

}

docWindow::~docWindow()
{
    delete ui->docwindow_tree_pat;
    delete ui->docwindow_btn_bodytmp_pat;
    delete ui->docwindow_btn_htrate_pat;
    delete ui->docwindow_btn_blpress_pat;
    delete ui->docwindow_btn_quit;
    delete ui->docwindow_btn_discharge;
    delete ui->docwindow_tbrow_name_pat;
    delete ui->docwindow_tbrow_sex_pat;
    delete ui->docwindow_tbrow_age_pat;
    delete ui->docwindow_tbrow_bodytmp_pat;
    delete ui->docwindow_tbrow_htrate_pat;
    delete ui->docwindow_tbrow_blpress_pat;
    delete ui->docwindow_tedit_cond_pat;
    delete ui;
}

void docWindow::on_docwindow_btn_quit_clicked()
{
    this->close();
}

void docWindow::on_docwindow_tree_pat_itemDoubleClicked(QTreeWidgetItem *item, int column)
{
    timer->start(5000);
    int cnt;
    for(cnt=0; cnt<count_pat; cnt++)
    {
        if(patInfo[cnt].pat_name==item->text(0))
        {
            break;
        }
    }
    ui->docwindow_tbrow_name_pat->setText("姓名："+patInfo[cnt].pat_name);
    if(patInfo[cnt].pat_sex == MALE)
    {
        ui->docwindow_tbrow_sex_pat->setText("性别：男");
    }
    else
    {
        ui->docwindow_tbrow_sex_pat->setText("性别：女");
    }
    ui->docwindow_tbrow_age_pat->setText("年龄："+QString::number(patInfo[cnt].pat_age));
    ui->docwindow_tbrow_bodytmp_pat->setText("体温："+QString::number(patInfo[cnt].body_tmp[29]));
    ui->docwindow_tbrow_htrate_pat->setText("血压："+QString::number(patInfo[cnt].hrt_rate[29]));
    ui->docwindow_tbrow_blpress_pat->setText("血压："+QString::number(patInfo[cnt].bld_press[29]));
    ui->docwindow_tedit_cond_pat->setText("病情："+patInfo[cnt].pat_cond);
    item_check=cnt;//标记选择的患者
}


void docWindow::on_docwindow_btn_discharge_clicked()
{
    //发送的数据：患者姓名
    //1 将发送的数据打包
    if(item_check<0)
    {
        QMessageBox::information(this, "出院信息", "请选择出院患者");
        return;
    }
    else
    {
        QString name_patient = patInfo[item_check].pat_name;
        qDebug() << name_patient;
        //封装数据：结构体
        struct discharge_struct dischar;
        qsnprintf(dischar.discharge_name_pat, 20, name_patient.toStdString().c_str());
        qDebug()<<dischar.discharge_name_pat;//打印信息
        //2 将出院信息发送给服务器端（云端）
        QHostAddress *addr = new QHostAddress(DISCHAR_SERVER_IP);
        qint64 ret = doc_udpsock->writeDatagram((char *)&dischar, sizeof(dischar), *addr, DISCHAR_SERVER_PORT);
        if(ret < 0)
        {
            QMessageBox::information(this, "出院信息", "出院窗口发送数据失败！");
            return;
        }
        else
        {
            QMessageBox::information(this, "出院信息", "出院成功！");
            //从云端获取数据后以下两个for循环及其之间的都注释掉，并把更新下面的注释去掉，然后在数据来源处把本地数据变成从云端获取
//            for(int i=item_check; i<count_pat-1; i++)
//            {
//                patInfo[i].pat_name=patInfo[i+1].pat_name;
//                patInfo[i].pat_sex=patInfo[i+1].pat_sex;
//                patInfo[i].pat_age=patInfo[i+1].pat_age;
//                for(int j=0; j<30; j++)
//                {
//                    patInfo[i].body_tmp[j]=patInfo[i+1].body_tmp[j];
//                    patInfo[i].hrt_rate[j]=patInfo[i+1].hrt_rate[j];
//                    patInfo[i].bld_press[j]=patInfo[i+1].bld_press[j];
//                }
//                patInfo[i].pat_cond=patInfo[i+1].pat_cond;
//            }
            count_pat=count_pat-1;
            //测试打印
            for(int i=0; i<count_pat; i++)
                qDebug()<<patInfo[i].pat_name;
            //更新
            this->close();
            docWindow *docwin = new docWindow(name_doctor);//创建医生窗口
            docwin->setAttribute(Qt::WA_DeleteOnClose);
            docwin->show();//医生窗口显示


        }
    }
}

void docWindow::slot_readyread()
{
    QByteArray ret;
    ret.resize(doc_udpsock->pendingDatagramSize());//*************************************
    doc_udpsock->readDatagram(ret.data(), ret.size());//ret.data()将byteArray转化为char*
    QString str = QString::fromUtf8(ret);
    //收到的云端患者数据放在字符串str里
    //将患者数量放在count_pat里、患者信息存放在struct pat_info patInfo[100]里？
    count_pat = 7;
    for(int cnt=0; cnt<count_pat; cnt++)
    {
        patInfo[cnt].pat_name = "修改";
        patInfo[cnt].pat_age = 30;
        patInfo[cnt].pat_cond = "病情";
        patInfo[cnt].pat_sex = MALE;
        for(int j=0;j<30;j++)
        {
            patInfo[cnt].bld_press[j] = 4;
            patInfo[cnt].body_tmp[j] = 5;
            patInfo[cnt].hrt_rate[j] = 6;
        }
    }
    QTreeWidgetItem *tree_patient[count_pat];
    for(int cnt=0; cnt<count_pat; cnt++)
    {
        tree_patient[cnt]=new QTreeWidgetItem(ui->docwindow_tree_pat);
        tree_patient[cnt]->setText(0, patInfo[cnt].pat_name);
    }

}

void docWindow::on_docwindow_btn_bodytmp_pat_clicked()
{
    if(item_check<0)
    {
        QMessageBox::information(this, "体温图信息", "请选择患者");
        return;
    }
    else
    {
        paintBodytmp *ptbywin = new paintBodytmp(patInfo[item_check].body_tmp);//创建体温图窗口
        ptbywin->setAttribute(Qt::WA_DeleteOnClose);
        ptbywin->show();//体温图窗口显示
    }
}

void docWindow::on_docwindow_btn_htrate_pat_clicked()
{
    if(item_check<0)
    {
        QMessageBox::information(this, "心率图信息", "请选择患者");
        return;
    }
    else
    {
        paintHtrate *pthtwin = new paintHtrate(patInfo[item_check].hrt_rate);//创建心率图窗口
        pthtwin->setAttribute(Qt::WA_DeleteOnClose);
        pthtwin->show();//心率图窗口显示
    }
}

void docWindow::on_docwindow_btn_blpress_pat_clicked()
{
    if(item_check<0)
    {
        QMessageBox::information(this, "血压图信息", "请选择患者");
        return;
    }
    else
    {
        paintBlpress *ptblwin = new paintBlpress(patInfo[item_check].bld_press);//创建血压图窗口
        ptblwin->setAttribute(Qt::WA_DeleteOnClose);
        ptblwin->show();//血压图窗口显示
    }
}


void docWindow::slot_timeout()
{
    //1 将发送的数据打包
    //封装数据：结构体
    struct reqInfo_struct req;
    qsnprintf(req.docName, 20, name_doctor.toStdString().c_str());
    qDebug()<<"time out"<<req.docName;//打印信息
    //2 将请求患者信息发送给服务器端（云端）
        QHostAddress *addr = new QHostAddress(REQINFO_SERVER_IP);
        qint64 ret = doc_udpsock->writeDatagram((char *)&req, sizeof(req), *addr, REQINFO_SERVER_PORT);
        if(ret < 0)
        {
            QMessageBox::information(this, "获取患者信息", "获取患者信息失败！");
            return;
        }

}
