#include "widget.h"
#include "ui_widget.h"

Widget::Widget(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::Widget)
{
    ui->setupUi(this);

    //显示提示
    ui->widget_ledit_usr->setPlaceholderText("用户名");
    ui->widget_ledit_passwd->setPlaceholderText("密码");
    ui->widget_ledit_passwd->setEchoMode(QLineEdit::Password);//设置密码为暗文显示
    ui->widget_btn_log->setCursor(QCursor(Qt::PointingHandCursor));//设置鼠标放在按钮上时为手型
    ui->widget_btn_reg->setCursor(QCursor(Qt::PointingHandCursor));
    ui->widget_btn_quit->setCursor(QCursor(Qt::PointingHandCursor));
    ui->widget_rbtn_doc->setCursor(QCursor(Qt::PointingHandCursor));
    ui->widget_rbtn_pat->setCursor(QCursor(Qt::PointingHandCursor));
    this->setWindowTitle("欢迎访问医疗管理系统！");

    rbtnGroup_pro = new QButtonGroup(this);//按钮分组
    rbtnGroup_pro->addButton(ui->widget_rbtn_doc, 0);
    rbtnGroup_pro->addButton( ui->widget_rbtn_pat, 1);
    ui->widget_rbtn_doc->setChecked(true);//默认是医生
    ui->widget_rbtn_pat->setChecked(false);

    //定义udp对象
    log_udpsock = new QUdpSocket();

    connect(this, SIGNAL(retSignal(int)), this, SLOT(slot_showResult(int)));
}

Widget::~Widget()
{
    delete ui->widget_ledit_usr;
    delete ui->widget_ledit_passwd;
    delete ui->widget_btn_log;
    delete ui->widget_btn_reg;
    delete ui->widget_btn_quit;
    delete ui->widget_rbtn_doc;
    delete ui->widget_rbtn_pat;
    delete ui;
}

void Widget::on_widget_btn_quit_clicked()
{
    this->close();
}

void Widget::on_widget_btn_reg_clicked()
{
    regWindow *regwin = new regWindow();//创建注册窗口
    regwin->setAttribute(Qt::WA_DeleteOnClose);
    regwin->show();//注册窗口显示
}

void Widget::on_widget_btn_log_clicked()
{
    //发送的数据：用户名，密码，职业
    //1 将发送的数据打包
    QString usr = ui->widget_ledit_usr->text();
    QString passwd = ui->widget_ledit_passwd->text();
    int prof=0;
    if(usr.isEmpty() || passwd.isEmpty())
    {
        QMessageBox::information(this, "登录信息", "请输入完整登录信息！");
        return;
    }
    switch(rbtnGroup_pro->checkedId())
    {
        case 0:
            prof = DOCTOR;
            break;
        case 1:
            prof = PATIENT;
            break;
    }
    //封装数据：结构体
    struct log_struct log;
    qsnprintf(log.log_usr, 20, usr.toStdString().c_str());
    qsnprintf(log.log_passwd, 20, passwd.toStdString().c_str());
    log.log_prof = prof;
    qDebug()<<usr<<":"<<passwd<<":"<<log.log_prof;
//    //2 将登录信息发送给服务器端（云端）
    QHostAddress *addr = new QHostAddress(LOG_SERVER_IP);
    qint64 ret = log_udpsock->writeDatagram((char *)&log, sizeof(log), *addr, LOG_SERVER_PORT);
    if(ret < 0)
    {
        QMessageBox::information(this, "登录信息", "登录窗口发送数据失败！");
    }


    else
    {
        QMessageBox::information(this, "登录信息", "登录成功！");
        //log_udpsock_rcv = new QUdpSocket();
        //将接受数据的进程与ip和端口号绑定
        //log_udpsock_rcv->bind(QHostAddress(LOG_CLIENT_IP), LOG_CLIENT_PORT);
        //udp接收数据：当udp接收到数据后，会产生一个readyRead()信号，将该信号与一个接收槽函数关联
        //connect(log_udpsock_rcv, SIGNAL(readyRead()), this, SLOT(slot_readyread()));
        connect(log_udpsock, SIGNAL(readyRead()), this, SLOT(slot_readyread()));
    }

    //emit retSignal(ACK_DOCTOR);//调试用，用云端回传确认信息时注释掉

}

void Widget::slot_readyread()
{
    QByteArray ret;
    ret.resize(log_udpsock->pendingDatagramSize());//*****************************
    log_udpsock->readDatagram(ret.data(), ret.size());//ret.data()将byteArray转化为char*
    QString str = QString::fromUtf8(ret);
    int ret_int = str.toInt();
    if(ret_int == ACK_PATIENT)
    {
        emit retSignal(ACK_PATIENT);
    }
    else if(ret_int == ACK_DOCTOR)
    {
        emit retSignal(ACK_DOCTOR);
    }
    else
    {
        emit retSignal(NAK);
    }
}

void Widget::slot_showResult(int ret)
{
    if(ret == ACK_DOCTOR)
    {
        QString name_doc = ui->widget_ledit_usr->text();
        docWindow *docwin = new docWindow(name_doc);//创建医生窗口
        docwin->setAttribute(Qt::WA_DeleteOnClose);
        docwin->show();//医生窗口显示
    }
    else if(ret == ACK_PATIENT)
    {
        QString name_pat = ui->widget_ledit_usr->text();
        patWindow *patwin = new patWindow(name_pat);//创建患者窗口
        patwin->setAttribute(Qt::WA_DeleteOnClose);
        patwin->show();//患者窗口显示
    }
    else
    {
        QMessageBox::information(this, "登录提示", "登录失败！");
    }
}
