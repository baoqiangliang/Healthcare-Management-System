#ifndef WIDGET_H
#define WIDGET_H

#include <QWidget>
#include <QDebug>
#include <QButtonGroup>
#include <QByteArray>
#include <QString>
#include "regwindow.h"
#include "docwindow.h"
#include "patwindow.h"

namespace Ui {
class Widget;
}

#define DOCTOR 0
#define PATIENT 1

#define ACK_PATIENT 1
#define ACK_DOCTOR 0
#define NAK -1

#define LOG_SERVER_IP "192.168.3.10"
#define LOG_SERVER_PORT 1234

//#define LOG_CLIENT_IP "192.168.1.1"
//#define LOG_CLIENT_PORT 1233

struct log_struct
{
    int num_ver = 0x04;//版本号0x04
    int type = 2;//类型02表示是登录信息
    char log_usr[20];
    char log_passwd[20];
    int log_prof;
    int check_crc = 0;//不进行校验
};

class Widget : public QWidget
{
    Q_OBJECT

public:
    explicit Widget(QWidget *parent = 0);
    ~Widget();

public slots:
    void slot_readyread(void);
    void slot_showResult(int);

signals:
    void retSignal(int);

private slots:
    void on_widget_btn_quit_clicked();

    void on_widget_btn_reg_clicked();

    void on_widget_btn_log_clicked();

private:
    Ui::Widget *ui;
    QUdpSocket *log_udpsock;//声明udp对象
    //QUdpSocket *log_udpsock_rcv;

    QButtonGroup *rbtnGroup_pro;
};

#endif // WIDGET_H
