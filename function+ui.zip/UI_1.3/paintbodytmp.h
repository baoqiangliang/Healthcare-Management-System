#ifndef PAINTBODYTMP_H
#define PAINTBODYTMP_H

#include <QWidget>
#include <QPainter>
#include <QList>
#include <QTimer>
#include <QtCore/qmath.h>
#include <QPointF>
#include <QDebug>

namespace Ui {
class paintBodytmp;
}

class paintBodytmp : public QWidget
{
    Q_OBJECT

public:
    explicit paintBodytmp(float* body_tmp, QWidget *parent = 0);
    ~paintBodytmp();
    void paintEvent(QPaintEvent*);
    float* bodyTmp;

public slots:
    void slot_update_data(void);

private:
    Ui::paintBodytmp *ui;
    //QList<float>表示列表QList中存放的数据的类型是float
    QList<int> xList;   //横坐标为day
    QList<float> yList; //纵坐标为体温
    QTimer *m_timer;
    int x;
    int draw_count;
};

#endif // PAINTBODYTMP_H
