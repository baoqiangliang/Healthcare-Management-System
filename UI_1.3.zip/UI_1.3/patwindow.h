#ifndef PATWINDOW_H
#define PATWINDOW_H

#include <QWidget>

namespace Ui {
class patwindow;
}

class patwindow : public QWidget
{
    Q_OBJECT

public:
    explicit patwindow(QWidget *parent = 0);
    ~patwindow();

private:
    Ui::patwindow *ui;
};

#endif // PATWINDOW_H
