#ifndef DOCWINDOW_H
#define DOCWINDOW_H

#include <QWidget>

namespace Ui {
class docwindow;
}

class docwindow : public QWidget
{
    Q_OBJECT

public:
    explicit docwindow(QWidget *parent = 0);
    ~docwindow();

private:
    Ui::docwindow *ui;
};

#endif // DOCWINDOW_H
