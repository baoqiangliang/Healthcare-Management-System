#include "widget.h"
#include "ui_widget.h"

Widget::Widget(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::Widget)
{
    ui->setupUi(this);
}

Widget::~Widget()
{
    delete ui;
}

void Widget::on_widget_btn_reg_clicked()
{
    RegWindow *a = new RegWindow();
    a->show();
}

void Widget::on_widget_btn_log_clicked()
{
    patwindow *b = new patwindow();
    b->show();
}

void Widget::on_widget_btn_quit_clicked()
{
    docwindow *c = new docwindow();
    c->show();
}

