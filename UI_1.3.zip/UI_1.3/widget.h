#ifndef WIDGET_H
#define WIDGET_H

#include <QWidget>
#include <regwindow.h>
#include <docwindow.h>
#include <patwindow.h>

namespace Ui {
class Widget;
}

class Widget : public QWidget
{
    Q_OBJECT

public:
    explicit Widget(QWidget *parent = 0);
    ~Widget();


private slots:
    void on_widget_btn_reg_clicked();

private slots:
    void on_widget_btn_log_clicked();

private slots:
    void on_widget_btn_quit_clicked();


private:
    Ui::Widget *ui;


};

#endif // WIDGET_H
