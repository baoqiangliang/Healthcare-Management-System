#include "patwindow.h"
#include "ui_patwindow.h"

patwindow::patwindow(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::patwindow)
{
    ui->setupUi(this);
}

patwindow::~patwindow()
{
    delete ui;
}
