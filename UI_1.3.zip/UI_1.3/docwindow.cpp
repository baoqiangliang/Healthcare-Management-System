#include "docwindow.h"
#include "ui_docwindow.h"

docwindow::docwindow(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::docwindow)
{
    ui->setupUi(this);
}

docwindow::~docwindow()
{
    delete ui;
}
