#include "painthtrate.h"
#include "ui_painthtrate.h"

paintHtrate::paintHtrate(float* htrate, QWidget *parent) :
    QWidget(parent),
    ui(new Ui::paintHtrate)
{
    ui->setupUi(this);
    this->setWindowTitle("心率图");
    htRate=htrate;

    x=0;
    draw_count=0;
    m_timer = new QTimer(this);
    m_timer->start(40);
    connect(m_timer, SIGNAL(timeout()), this, SLOT(slot_update_data()));
}

paintHtrate::~paintHtrate()
{
    delete ui;
}

void paintHtrate::paintEvent(QPaintEvent *)
{
    //画波形图：心率图 数据 定时器产生数据-->QList(链表)-->画波形图从QList中读取数据，根据数据画出波形图
    QPainter painter(this);
    //设置画笔
    QPen pen;
    pen.setColor(Qt::blue);
    pen.setStyle(Qt::SolidLine);
    pen.setWidth(0.5);
    painter.setPen(pen);

    //设置画图区域
    painter.setViewport(50, 50, width()-100, height()-100);//设置画图物理区域
    painter.setWindow(-30, -130, 30, 80);//设置逻辑区域
    painter.fillRect(-30, -130, 30, 80, Qt::white);//将逻辑区域背景设置为白色

//    //画一条直线：波形在直线上产生
//    painter.drawLine(-10, 0, 10, 0);
    //画波形
    for(int i=0; i<yList.count(); i++)
    {
        if(i == 0)
        {
            //第一次：画一个点
            painter.drawPoint(QPointF(xList[i], yList[i]));
        }
        else
        {
            //以后次数：画线
            painter.drawLine(QPointF(xList[i-1], yList[i-1]),
                             QPointF(xList[i], yList[i]));
        }
    }
}

void paintHtrate::slot_update_data()
{
    x+=0.5;
    draw_count++;
    if(draw_count%2 == 0)
    {
        xList.append(draw_count/2-30);
        yList.append(htRate[draw_count/2-1]*(-1));
        //qDebug()<<htRate[draw_count/2-1];
        update();
    }
    if(draw_count == 60)
    {
        xList.clear();
        yList.clear();
        draw_count = 0;
        x = 0;
    }
}
