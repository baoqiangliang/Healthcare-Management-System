#include "docwindow.h"
#include "ui_docwindow.h"
QString name_doctor;// 医生姓名
extern QString name_patient;// 患者姓名
extern QStringList doc_name;
extern QStringList doc_passwd;
extern QStringList doc_sex;
extern QStringList doc_age;
extern QStringList pat_name;
extern QStringList pat_passwd;
extern QStringList pat_sex;
extern QStringList pat_age;
extern QStringList pat_error;
extern QStringList patofdoc_num;
extern QStringList docofpat_name;
extern QStringList docofpat_num;
docWindow::docWindow(QString name_doc, QWidget *parent) :
    QWidget(parent),
    ui(new Ui::docWindow)
{
    ui->setupUi(this);

    this->setWindowTitle("欢迎使用医疗管理系统");
    //定义定时器
    timer = new QTimer(this);
    //设置定时器超时时执行的槽函数
    connect(timer,SIGNAL(timeout()),this,SLOT(slot_timeout()));
    ui->docwindow_btn_bodytmp_pat->setCursor(QCursor(Qt::PointingHandCursor));//设置鼠标放在按钮上时为手型
    ui->docwindow_btn_htrate_pat->setCursor(QCursor(Qt::PointingHandCursor));
    ui->docwindow_btn_blpress_pat->setCursor(QCursor(Qt::PointingHandCursor));
    ui->docwindow_btn_quit->setCursor(QCursor(Qt::PointingHandCursor));
    ui->docwindow_btn_discharge->setCursor(QCursor(Qt::PointingHandCursor));

    //定义udp对象
    doc_udpsock = new QUdpSocket();
    //doc_udpsock_rcv = new QUdpSocket();
    //将接受数据的进程与ip和端口号绑定
    //doc_udpsock_rcv->bind(QHostAddress(DOC_CLIENT_IP), DOC_CLIENT_PORT);
    //udp接收数据：当udp接收到数据后，会产生一个readyRead()信号，将该信号与一个接收槽函数关联
    //connect(doc_udpsock_rcv, SIGNAL(readyRead()), this, SLOT(slot_readyread()));
    connect(doc_udpsock, SIGNAL(readyRead()), this, SLOT(slot_readyread()));

    name_doctor = name_doc;
    for(int i=0;i<doc_name.length();i++)
    {
        if(!QString::compare(doc_name[i],name_doctor))
        {
            count_pat=patofdoc_num[i].toInt();
        }
    }
    for(int i=0;i<count_pat;i++)
    {
        for(int j=0;j<docofpat_name.length();j++)
        {
            if((i==1)&&(!QString::compare(docofpat_name[j],name_doctor))&&(QString::compare(pat_name[j],patInfo[i-1].pat_name)!=0))
            {
                patInfo[i].pat_name=pat_name[j];
                patInfo[i].pat_sex=pat_sex[j].toInt();
                patInfo[i].pat_age=pat_age[j].toInt();
                patInfo[i].pat_cond=pat_error[j];
            }
            if((i==2)&&(!QString::compare(docofpat_name[j],name_doctor))&&(QString::compare(pat_name[j],patInfo[i-1].pat_name)!=0)&&(QString::compare(pat_name[j],patInfo[i-2].pat_name)!=0))
            {
                patInfo[i].pat_name=pat_name[j];
                patInfo[i].pat_sex=pat_sex[j].toInt();
                patInfo[i].pat_age=pat_age[j].toInt();
                patInfo[i].pat_cond=pat_error[j];
            }
            if((i==3)&&(!QString::compare(docofpat_name[j],name_doctor))&&(QString::compare(pat_name[j],patInfo[i-1].pat_name)!=0)&&(QString::compare(pat_name[j],patInfo[i-2].pat_name)!=0)&&(QString::compare(pat_name[j],patInfo[i-3].pat_name)!=0))
            {
                patInfo[i].pat_name=pat_name[j];
                patInfo[i].pat_sex=pat_sex[j].toInt();
                patInfo[i].pat_age=pat_age[j].toInt();
                patInfo[i].pat_cond=pat_error[j];
            }
            if((i==0)&&(!QString::compare(docofpat_name[j],name_doctor)))
            {
                patInfo[i].pat_name=pat_name[j];
                patInfo[i].pat_sex=pat_sex[j].toInt();
                patInfo[i].pat_age=pat_age[j].toInt();
                patInfo[i].pat_cond=pat_error[j];
            }
        }

    }
//            memcpy(patInfo[2].body_tmp, temp_arr, sizeof(temp_arr));
//            memcpy(patInfo[2].hrt_rate, temp_arr, sizeof(temp_arr));
//            memcpy(patInfo[2].bld_press, temp_arr, sizeof(temp_arr));

    ui->docwindow_tree_pat->setHeaderLabel(name_doc+"医生，您好");
    QTreeWidgetItem *tree_patient[count_pat];
    for(int cnt=0; cnt<count_pat; cnt++)
    {
        tree_patient[cnt]=new QTreeWidgetItem(ui->docwindow_tree_pat);
        tree_patient[cnt]->setText(0, patInfo[cnt].pat_name);
    }

    //向云端请求患者信息
    //发送的数据：医生姓名
    //1 将发送的数据打包
    //封装数据：结构体
    struct reqInfo_struct req;
    qsnprintf(req.docName, 20, name_doctor.toStdString().c_str());
    qDebug()<<req.docName;//打印信息
    //2 将请求患者信息发送给服务器端（云端）
//        QHostAddress *addr = new QHostAddress(REQINFO_SERVER_IP);
//        qint64 ret = doc_udpsock->writeDatagram((char *)&req, sizeof(req), *addr, REQINFO_SERVER_PORT);
//        if(ret < 0)
//        {
//            QMessageBox::information(this, "获取患者信息", "获取患者信息失败！");
//            return;
//        }



    //int column_pat=count_pat-1;

    ui->docwindow_tbrow_name_pat->setText("姓名：");
    ui->docwindow_tbrow_sex_pat->setText("性别：");
    ui->docwindow_tbrow_age_pat->setText("年龄：");
    ui->docwindow_tedit_cond_pat->setText("病情：");
    ui->docwindow_tbrow_bodytmp_pat->setText("体温：");
    ui->docwindow_tbrow_htrate_pat->setText("心率：");
    ui->docwindow_tbrow_blpress_pat->setText("血压：");

}

docWindow::~docWindow()
{
    delete ui->docwindow_tree_pat;
    delete ui->docwindow_btn_bodytmp_pat;
    delete ui->docwindow_btn_htrate_pat;
    delete ui->docwindow_btn_blpress_pat;
    delete ui->docwindow_btn_quit;
    delete ui->docwindow_btn_discharge;
    delete ui->docwindow_tbrow_name_pat;
    delete ui->docwindow_tbrow_sex_pat;
    delete ui->docwindow_tbrow_age_pat;
    delete ui->docwindow_tbrow_bodytmp_pat;
    delete ui->docwindow_tbrow_htrate_pat;
    delete ui->docwindow_tbrow_blpress_pat;
    delete ui->docwindow_tedit_cond_pat;
    delete ui;
}

void docWindow::on_docwindow_btn_quit_clicked()
{
    this->close();
}

void docWindow::on_docwindow_tree_pat_itemDoubleClicked(QTreeWidgetItem *item, int column)
{
    timer->start(5000);
    int cnt;
    for(cnt=0; cnt<count_pat; cnt++)
    {
        if(patInfo[cnt].pat_name==item->text(0))
        {
            break;
        }
    }
    ui->docwindow_tbrow_name_pat->setText("姓名："+patInfo[cnt].pat_name);
    if(patInfo[cnt].pat_sex == MALE)
    {
        ui->docwindow_tbrow_sex_pat->setText("性别：男");
    }
    else
    {
        ui->docwindow_tbrow_sex_pat->setText("性别：女");
    }
    ui->docwindow_tbrow_age_pat->setText("年龄："+QString::number(patInfo[cnt].pat_age));
    ui->docwindow_tbrow_bodytmp_pat->setText("体温："+QString::number(patInfo[cnt].body_tmp[29]));
    ui->docwindow_tbrow_htrate_pat->setText("心率："+QString::number(patInfo[cnt].hrt_rate[29]));
    ui->docwindow_tbrow_blpress_pat->setText("血压："+QString::number(patInfo[cnt].bld_press[29]));
    ui->docwindow_tedit_cond_pat->setText("病情："+patInfo[cnt].pat_cond.split("：")[1]);
    item_check=cnt;//标记选择的患者
}


void docWindow::on_docwindow_btn_discharge_clicked()
{
    //发送的数据：患者姓名
    //1 将发送的数据打包
    if(item_check<0)
    {
        QMessageBox::information(this, "出院信息", "请选择出院患者");
        return;
    }
    else
    {
        QString name_patient = patInfo[item_check].pat_name;
        qDebug() << name_patient;
        //封装数据：结构体
        struct discharge_struct dischar;
        qsnprintf(dischar.discharge_name_pat, 20, name_patient.toStdString().c_str());
        qDebug()<<dischar.discharge_name_pat;//打印信息
        //2 将出院信息发送给服务器端（云端）
//        QHostAddress *addr = new QHostAddress(DISCHAR_SERVER_IP);
//        qint64 ret = doc_udpsock->writeDatagram((char *)&dischar, sizeof(dischar), *addr, DISCHAR_SERVER_PORT);
//        if(ret < 0)
//        {
//            QMessageBox::information(this, "出院信息", "出院窗口发送数据失败！");
//            return;
//        }
//        else
//        {
        for(int i=item_check; i<count_pat-1; i++)
        {
            patInfo[i].pat_name=patInfo[i+1].pat_name;
            patInfo[i].pat_sex=patInfo[i+1].pat_sex;
            patInfo[i].pat_age=patInfo[i+1].pat_age;
            for(int j=0; j<30; j++)
            {
                patInfo[i].body_tmp[j]=patInfo[i+1].body_tmp[j];
                patInfo[i].hrt_rate[j]=patInfo[i+1].hrt_rate[j];
                patInfo[i].bld_press[j]=patInfo[i+1].bld_press[j];
            }
            patInfo[i].pat_cond=patInfo[i+1].pat_cond;
        }
        //count_pat=count_pat-1;
        for(int i=0;i<doc_name.length();i++)
        {
            if(!QString::compare(doc_name[i],name_doctor))
            {
                patofdoc_num[i] = QString::number(patofdoc_num[i].toInt()-1);
            }
        }
        for(int i=0;i<pat_name.length();i++)
        {
            if(!QString::compare(pat_name[i],name_patient))
            {
                docofpat_num[i] = "0";
                docofpat_name[i] = "0";
            }
        }
        QMessageBox::information(this, "出院信息", "出院成功！");
            //从云端获取数据后以下两个for循环及其之间的都注释掉，并把更新下面的注释去掉，然后在数据来源处把本地数据变成从云端获取
            //测试打印
        for(int i=0; i<count_pat; i++)
            qDebug()<<patInfo[i].pat_name;
        for(int i=0; i<count_pat; i++)
            qDebug()<<docofpat_name[i];
            //更新
        this->close();
        docWindow *docwin = new docWindow(name_doctor);//创建医生窗口
        docwin->setAttribute(Qt::WA_DeleteOnClose);
        docwin->show();//医生窗口显示


        //}
    }
}

void docWindow::slot_readyread()
{
    QByteArray ret;
    ret.resize(doc_udpsock->pendingDatagramSize());//*************************************
    doc_udpsock->readDatagram(ret.data(), ret.size());//ret.data()将byteArray转化为char*
    QString str = QString::fromUtf8(ret);
    //收到的云端患者数据放在字符串str里
    //将患者数量放在count_pat里、患者信息存放在struct pat_info patInfo[100]里？
    QStringList list1 = str.split(":");
    QString pat_num = list1[0];
    QString pat_all_info = list1[1];
    QStringList list2 = pat_all_info.split(";");
    count_pat=pat_num.toInt();
    for(int cnt=0; cnt<count_pat; cnt++)
    {
        patInfo[cnt].pat_name = list2[cnt].split("-")[0];
        patInfo[cnt].pat_age = list2[cnt].split("-")[2].toInt();
        patInfo[cnt].pat_cond = list2[cnt].split("-")[3];
        patInfo[cnt].pat_sex = list2[cnt].split("-")[1].toInt();
        for(int j=0;j<count_pat;j++)
        {
            patInfo[cnt].bld_press[j] = list2[cnt].split("-")[5].split(",")[j].toFloat();
            patInfo[cnt].body_tmp[j] = list2[cnt].split("-")[4].split(",")[j].toFloat();
            patInfo[cnt].hrt_rate[j] = list2[cnt].split("-")[6].split(",")[j].toFloat();
        }
    }
    QTreeWidgetItem *tree_patient[count_pat];
    for(int cnt=0; cnt<count_pat; cnt++)
    {
        tree_patient[cnt]=new QTreeWidgetItem(ui->docwindow_tree_pat);
        tree_patient[cnt]->setText(0, patInfo[cnt].pat_name);
    }

}

void docWindow::on_docwindow_btn_bodytmp_pat_clicked()
{
    if(item_check<0)
    {
        QMessageBox::information(this, "体温图信息", "请选择患者");
        return;
    }
    else
    {
        paintBodytmp *ptbywin = new paintBodytmp(patInfo[item_check].body_tmp);//创建体温图窗口
        ptbywin->setAttribute(Qt::WA_DeleteOnClose);
        ptbywin->show();//体温图窗口显示
    }
}

void docWindow::on_docwindow_btn_htrate_pat_clicked()
{
    if(item_check<0)
    {
        QMessageBox::information(this, "心率图信息", "请选择患者");
        return;
    }
    else
    {
        paintHtrate *pthtwin = new paintHtrate(patInfo[item_check].hrt_rate);//创建心率图窗口
        pthtwin->setAttribute(Qt::WA_DeleteOnClose);
        pthtwin->show();//心率图窗口显示
    }
}

void docWindow::on_docwindow_btn_blpress_pat_clicked()
{
    if(item_check<0)
    {
        QMessageBox::information(this, "血压图信息", "请选择患者");
        return;
    }
    else
    {
        paintBlpress *ptblwin = new paintBlpress(patInfo[item_check].bld_press);//创建血压图窗口
        ptblwin->setAttribute(Qt::WA_DeleteOnClose);
        ptblwin->show();//血压图窗口显示
    }
}


void docWindow::slot_timeout()
{
    //1 将发送的数据打包
    //封装数据：结构体
    struct reqInfo_struct req;
    qsnprintf(req.docName, 20, name_doctor.toStdString().c_str());
    qDebug()<<"time out"<<req.docName;//打印信息
    //2 将请求患者信息发送给服务器端（云端）
//        QHostAddress *addr = new QHostAddress(REQINFO_SERVER_IP);
//        qint64 ret = doc_udpsock->writeDatagram((char *)&req, sizeof(req), *addr, REQINFO_SERVER_PORT);
//        if(ret < 0)
//        {
//            QMessageBox::information(this, "获取患者信息", "获取患者信息失败！");
//            return;
//        }

}
