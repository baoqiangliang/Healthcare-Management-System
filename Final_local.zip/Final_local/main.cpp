#include "widget.h"
#include <QApplication>
QStringList doc_name;
QStringList doc_passwd;
QStringList doc_sex;
QStringList doc_age;
QStringList pat_name;
QStringList pat_passwd;
QStringList pat_sex;
QStringList pat_age;
QStringList pat_error;
QStringList patofdoc_num;
QStringList docofpat_name;
QStringList docofpat_num;
int main(int argc, char *argv[])
{
    QApplication a(argc, argv);
    Widget w;
    w.show();

    return a.exec();
}
