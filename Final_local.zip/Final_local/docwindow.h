#ifndef DOCWINDOW_H
#define DOCWINDOW_H

#include <QWidget>
#include <QTreeWidgetItem>
#include <QString>
#include <QDebug>
#include <QUdpSocket>
#include <QHostAddress>
#include <QMessageBox>
#include "paintbodytmp.h"
#include "painthtrate.h"
#include "paintblpress.h"
#include <QTimer>

namespace Ui {
class docWindow;
}

#define MALE 0
#define FEMALE 1

#define REQINFO_SERVER_IP "192.168.1.102"
#define REQINFO_SERVER_PORT 1234

#define DISCHAR_SERVER_IP "192.168.3.10"
#define DISCHAR_SERVER_PORT 1234

//#define DOC_CLIENT_IP "192.168.1.1"
//#define DOC_CLIENT_PORT 1233

struct pat_info
{
    QString pat_name;
    int  pat_sex;
    int  pat_age;
    float  body_tmp[30]={36.1,36.5,36.4,37.6,37.3,37.1,36.5,38.6,38.9,38.5,38.1,37.7,37.4,37.1,36.6,36.5,36.7,36.7,36.9,37.1,37.5,37.3,37.6,37.1,37.2,37.9,37.5,37.4,37.1,36.9};
    float  hrt_rate[30]={62,67,69,75,77,78,78,77,77,75,74,75,77,78,80,79,76,77,76,77,71,62,70,72,73,75,80,86,83,74};
    float  bld_press[30]={98,86,80,75,77,78,78,82,77,75,74,89,77,78,80,89,82,77,76,77,71,77,82,89,93,98,95,90,83,80};
    QString pat_cond;
};

struct reqInfo_struct
{
    int num_ver = 0x04;//版本号0x04
    int type = 6;//类型06表示是请求 医生的患者信息
    char docName[20];
    int check_crc = 0;//不进行校验
};

struct discharge_struct
{
    int num_ver = 0x04;//版本号0x04
    int type = 5;//类型05表示是出院信息
    char discharge_name_pat[20];
    int check_crc = 0;//不进行校验
};

class docWindow : public QWidget
{
    Q_OBJECT

public:
    explicit docWindow(QString name_doc, QWidget *parent = 0);
    ~docWindow();


    struct pat_info patInfo[10];
    int count_pat=1;
    int item_check=-1; // 选中患者序号，-1表示没有选中

public slots:
    void slot_readyread(void);
    void slot_timeout();

private slots:
    void on_docwindow_btn_quit_clicked();

    void on_docwindow_tree_pat_itemDoubleClicked(QTreeWidgetItem *item, int column);

    void on_docwindow_btn_discharge_clicked();

    void on_docwindow_btn_bodytmp_pat_clicked();

    void on_docwindow_btn_htrate_pat_clicked();

    void on_docwindow_btn_blpress_pat_clicked();


private:
    Ui::docWindow *ui;
    QUdpSocket *doc_udpsock;//声明udp对象
    //QUdpSocket *doc_udpsock_rcv;
    QTimer *timer;
};

#endif // DOCWINDOW_H
