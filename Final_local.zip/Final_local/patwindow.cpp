#include "patwindow.h"
#include "ui_patwindow.h"
QString name_patient;// 患者姓名
extern QStringList doc_name;
extern QStringList doc_passwd;
extern QStringList doc_sex;
extern QStringList doc_age;
extern QStringList pat_name;
extern QStringList pat_passwd;
extern QStringList pat_sex;
extern QStringList pat_age;
extern QStringList pat_error;
extern QStringList patofdoc_num;
extern QStringList docofpat_name;
extern QStringList docofpat_num;
extern QString name_doctor;
patWindow::patWindow(QString name_pat, QWidget *parent) :
    QWidget(parent),
    ui(new Ui::patWindow)
{
    ui->setupUi(this);

    this->setWindowTitle("欢迎使用医疗管理系统");
    ui->patwindow_btn_order->setCursor(QCursor(Qt::PointingHandCursor));//设置鼠标放在按钮上时为手型
    ui->patwindow_btn_disorder->setCursor(QCursor(Qt::PointingHandCursor));
    ui->patwindow_btn_quit->setCursor(QCursor(Qt::PointingHandCursor));
    ui->patwindow_tree_doc->setHeaderLabel(name_pat+"，您好，请预约");

    //定义udp对象
    getmes_udpsock = new QUdpSocket();
    //getmes_udpsock_rcv = new QUdpSocket();
    order_udpsock = new QUdpSocket();
    //struct getdocmes_struct getmes;
    //2 将预约信息发送给服务器端（云端）
//    QHostAddress *addr = new QHostAddress(GETMES_SERVER_IP);
//    qint64 ret = getmes_udpsock->writeDatagram((char *)&getmes, sizeof(getmes), *addr, GETMES_SERVER_PORT);
//    if(ret < 0)
//    {
//        QMessageBox::information(this, "预约信息", "预约窗口发送数据失败！");
//        return;
//    }
//    else
//    {
//        QMessageBox::information(this, "预约信息", "预约成功！");
//        ui->patwindow_tbrow_orderinfo->setText("您已预约"+name_doctor+"医生");
//    }
    name_patient = name_pat;
    //getmes_udpsock_rcv->bind(QHostAddress(GETMES_CLIENT_IP), GETMES_CLIENT_PORT);
    //udp接收数据：当udp接收到数据后，会产生一个readyRead()信号，将该信号与一个接收槽函数关联
    //connect(getmes_udpsock_rcv, SIGNAL(readyRead()), this, SLOT(slot_readyread_doc()));
    connect(getmes_udpsock, SIGNAL(readyRead()), this, SLOT(slot_readyread_doc()));
    //测试用
    count_doc=doc_name.length();

    for(int i=0;i<count_doc;i++)
    {
        docInfo[i].doc_name=doc_name[i];
        docInfo[i].doc_sex=doc_sex[i].toInt();
        docInfo[i].doc_age=doc_age[i].toInt();
    }
    QTreeWidgetItem *tree_doctor[count_doc];
    for(int cnt=0; cnt<count_doc; cnt++)
    {
        tree_doctor[cnt]=new QTreeWidgetItem(ui->patwindow_tree_doc);
        tree_doctor[cnt]->setText(0, docInfo[cnt].doc_name);
    }

    for(int i=0;i<pat_name.length();i++)
    {
        if(!QString::compare(pat_name[i],name_patient))
        {
            if(!QString::compare(docofpat_num[i],"1"))
            {
               QString temp = docofpat_name[i];
               QString temp2 = pat_error[i];
               ui->patwindow_tbrow_orderinfo->setText("您已预约"+temp+"医生");
               ui->patwindow_tbrow_name_doc->setText("姓名：");
               ui->patwindow_tbrow_sex_doc->setText("性别：");
               ui->patwindow_tbrow_age_doc->setText("年龄：");
               ui->patwindow_tedit_cond->setText("请输入您的病情："+temp2.split("：")[1]);
            }
            else
            {
                ui->patwindow_tbrow_orderinfo->setText("您尚未预约");
                ui->patwindow_tbrow_name_doc->setText("姓名：");
                ui->patwindow_tbrow_sex_doc->setText("性别：");
                ui->patwindow_tbrow_age_doc->setText("年龄：");
                ui->patwindow_tedit_cond->setText("请输入您的病情：");
            }
        }
    }
}

patWindow::~patWindow()
{
    delete ui->patwindow_tree_doc;
    delete ui->patwindow_tbrow_orderinfo;
    delete ui->patwindow_tbrow_name_doc;
    delete ui->patwindow_tbrow_sex_doc;
    delete ui->patwindow_tbrow_age_doc;
    delete ui->patwindow_tedit_cond;
    delete ui->patwindow_btn_order;
    delete ui->patwindow_btn_disorder;
    delete ui->patwindow_btn_quit;
    delete ui;
}

void patWindow::on_patwindow_btn_quit_clicked()
{
    this->close();
}

void patWindow::on_patwindow_tree_doc_itemDoubleClicked(QTreeWidgetItem *item, int column)
{
    int cnt;
    for(cnt=0; cnt<count_doc; cnt++)
    {
        if(docInfo[cnt].doc_name==item->text(0))
        {
            break;
        }
    }
    ui->patwindow_tbrow_name_doc->setText("姓名："+docInfo[cnt].doc_name);
    if(docInfo[cnt].doc_sex == MALE)
    {
        ui->patwindow_tbrow_sex_doc->setText("性别：男");
    }
    else
    {
        ui->patwindow_tbrow_sex_doc->setText("性别：女");
    }
    ui->patwindow_tbrow_age_doc->setText("年龄："+QString::number(docInfo[cnt].doc_age));

    item_check=cnt;//标记选择的医生
}

void patWindow::on_patwindow_btn_order_clicked()
{
    //发送的数据：患者姓名, 预约的医生姓名
    //1 将发送的数据打包
    if(item_check<0)
    {
        QMessageBox::information(this, "预约信息", "请选择您要预约的医生");
        return;
    }
    else
    {
        name_doctor = docInfo[item_check].doc_name;
        qDebug() << name_doctor;
        //封装数据：结构体
        struct order_struct ord;
        qsnprintf(ord.order_name_pat, 20, name_patient.toStdString().c_str());
        qsnprintf(ord.order_name_doc, 20, name_doctor.toStdString().c_str());
        qDebug()<<ord.order_name_pat<<":"<<ord.order_name_doc;//打印信息
        for(int i=0;i<pat_name.length();i++)
        {
            if(!QString::compare(pat_name[i],name_patient))
            {
                if(!QString::compare(docofpat_num[i],"0"))
                {
                    docofpat_num[i] = "1";
                    docofpat_name[i] = name_doctor;
                    for(int j=0;j<doc_name.length();j++)
                    {
                        if(!QString::compare(doc_name[j],name_doctor))
                        {
                            patofdoc_num[j] = QString::number(patofdoc_num[j].toInt()+1);
                            QMessageBox::information(this, "预约信息", "预约成功");
                            pat_error[i] = ui->patwindow_tedit_cond->toPlainText();
                            ui->patwindow_tbrow_orderinfo->setText("您已预约"+name_doctor+"医生");
                        }
                    }

                }
                else
                {
                    QMessageBox::information(this, "预约信息", "您已预约，请先取消");
                }
            }
        }
    }
}

void patWindow::on_patwindow_btn_disorder_clicked()
{
    //发送的数据：患者姓名, 取消预约的医生姓名
    //1 将发送的数据打包
    if(item_check<0)
    {
        QMessageBox::information(this, "取消预约信息", "请选择您要取消预约的医生");
        return;
    }
    else
    {
        QString name_doctor = docInfo[item_check].doc_name;
        qDebug() << name_doctor;
        //封装数据：结构体
        struct disord_struct disord;
        qsnprintf(disord.disord_name_pat, 20, name_patient.toStdString().c_str());
        qsnprintf(disord.disord_name_doc, 20, name_doctor.toStdString().c_str());
        qDebug()<<disord.disord_name_pat<<":"<<disord.disord_name_doc;//打印信息
        for(int i=0;i<pat_name.length();i++)
        {
            if(!QString::compare(pat_name[i],disord.disord_name_pat))
            {
                if(!QString::compare(docofpat_num[i],"1"))
                {

                    for(int j=0;j<doc_name.length();j++)
                    {
                        if(!QString::compare(doc_name[j],docofpat_name[i]))
                        {
                            docofpat_num[i] = "0";
                            docofpat_name[i] = "0";
                            patofdoc_num[j] = QString::number(patofdoc_num[j].toInt()-1);
                            QMessageBox::information(this, "取消预约信息", "取消预约成功");
                            pat_error[i] = "0";
                            ui->patwindow_tbrow_orderinfo->setText("您尚未预约！");
                        }
                    }

                }
                else
                {
                    QMessageBox::information(this, "取消信息", "您尚未预约，请先预约");
                }
            }
        }

    }
}


void patWindow::slot_readyread_doc()
{
    QByteArray ret;
    ret.resize(getmes_udpsock->pendingDatagramSize());//***************************************
    getmes_udpsock->readDatagram(ret.data(), ret.size());//ret.data()将byteArray转化为char*
    QString str = QString::fromUtf8(ret);
    QStringList list1 = str.split(":");
    QString doc_num = list1[0];
    QString doc_all_info = list1[1];
    QStringList list2 = doc_all_info.split(";");
    count_doc=doc_num.toInt();
    for(int cnt=0; cnt<count_doc; cnt++)
    {
        docInfo[cnt].doc_name=list2[cnt].split("-")[0];
        docInfo[cnt].doc_age = list2[cnt].split("-")[2].toInt();
        docInfo[cnt].doc_sex = list2[cnt].split("-")[1].toInt();
    }
    QTreeWidgetItem *tree_doctor[count_doc];
    for(int cnt=0; cnt<count_doc; cnt++)
    {
        tree_doctor[cnt]=new QTreeWidgetItem(ui->patwindow_tree_doc);
        tree_doctor[cnt]->setText(0, docInfo[cnt].doc_name);
    }

}
