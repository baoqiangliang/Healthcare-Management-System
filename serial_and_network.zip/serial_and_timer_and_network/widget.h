#ifndef WIDGET_H
#define WIDGET_H

#include <QWidget>
#include <QSerialPort>
#include <QTimer>
#include <QDebug>
#include <QUdpSocket>
#include <QMessageBox>
#define DATA_SERVER_IP "192.168.1.103"
#define DATA_SERVER_PORT 1234
namespace Ui {
class Widget;
}

struct data{
    int type = 8;
    float body_tmp;
    float hrt_rate;
    float bld_press;
};

class Widget : public QWidget
{
    Q_OBJECT

public:
    explicit Widget(QWidget *parent = 0);
    ~Widget();
private slots:
    void on_btn_start_clicked();
    void on_btn_ent_clicked();

    void on_pushButton_clicked();

public slots:
    void slot_timeout(void);
private:
    Ui::Widget *ui;

    QTimer *timer;
    QSerialPort *serial;
    QUdpSocket *udpsock;

};

#endif // WIDGET_H
