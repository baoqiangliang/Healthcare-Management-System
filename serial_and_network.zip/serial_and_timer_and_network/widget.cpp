#include "widget.h"
#include "ui_widget.h"

Widget::Widget(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::Widget)
{
    ui->setupUi(this);
    timer = new QTimer(this);
    connect(timer,SIGNAL(timeout()),this,SLOT(slot_timeout()));
    //启动定时器，并设置超时时间
    //定义串口对象
    serial = new QSerialPort(this);
    //设置串口的参数
    serial->setPortName("COM9");//串口名称
    //波特率
    serial->setBaudRate(115200);
    //数据位
    serial->setDataBits(QSerialPort::Data8);
    //停止位
    serial->setStopBits(QSerialPort::OneStop);
    //校验
    serial->setParity(QSerialPort::NoParity);
    //流控
    serial->setFlowControl(QSerialPort::NoFlowControl);
    //打开串口
    bool ret = serial->open(QSerialPort::ReadWrite);
    udpsock = new QUdpSocket();
    if(ret == false)
    {
        qDebug()<<"打开失败";
    }
    else
    {
        qDebug()<<"打开成功";
    }
}

Widget::~Widget()
{
    delete ui;
}


void Widget::slot_timeout()
{
    struct data snd;
    //打印一句话
    QByteArray rdData;
    rdData = "";
        //读阻塞函数，防止占用过高的CPU占用
        //while(serial->waitForReadyRead(10))
        //{
            rdData = serial->readAll();
        //}
        if(!rdData.isEmpty())
        {
            qDebug()<<"*****"<<rdData;
            QString string = rdData;
            ui->text_rec->setText(string);
            QStringList list = string.split(",");
            QString tmp = list[0];
            QString hrt = list[1];
            QString bld = list[2];
            snd.body_tmp = tmp.toFloat();
            snd.hrt_rate = hrt.toFloat();
            snd.bld_press = bld.toFloat();
            qDebug()<<tmp<<hrt<<bld;
            QHostAddress *addr = new QHostAddress(DATA_SERVER_IP);
            qint64 ret = udpsock->writeDatagram((char *)&snd, sizeof(snd), *addr, DATA_SERVER_PORT);
            if(ret < 0)
            {
                QMessageBox::information(this, "发送信息", "发送失败");
                return;
            }
            else
            {
                QMessageBox::information(this, "发送信息", "发送成功！");
            }

        }
}

void Widget::on_pushButton_clicked()
{
    timer->start(100);
}
